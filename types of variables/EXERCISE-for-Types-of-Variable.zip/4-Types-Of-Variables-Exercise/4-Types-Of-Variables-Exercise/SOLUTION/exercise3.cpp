#include <iostream>

using namespace std;

main() {

    int roomNumber;
    short floorLevel;
    string renterName, renterLastName;
    bool mealsIncluded;

}
